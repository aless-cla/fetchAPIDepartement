package cnns.com.example.kotlintestapp

data class DepartementObject(var text1: String?, var text2: String?, var id: Int?, var text3: String?)

