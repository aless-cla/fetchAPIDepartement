package cnns.com.example.kotlintestapp.models

data class Departement(
    val id: Int? = null,
    val nom: String? = null,
    val code: String? = null,
    val codeRegion: String? = null

)